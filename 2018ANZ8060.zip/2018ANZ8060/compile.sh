#!/bin/sh

g++ -std=c++14 -O3 -o DbScan DbScan.cc -IANN/include -LANN/lib -lANN
gcc -o  kmeans source.c -lm

